const MESSAGES = {
    LAST_SAVED: "Last saved at: ",
    LAST_RETRIEVED: "Last retrieved at: ",
};
