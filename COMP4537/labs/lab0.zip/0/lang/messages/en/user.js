const messages = {
    INVALID_INPUT: "Please enter a number between 3 and 7.",
    EXCELLENT_MEMORY: "Excellent memory!",
    WRONG_ORDER: "Wrong order! Try again.",
};

export default messages;
